# DevSecOps Case Study: Shift-Left Security with Trivy

Alternative DevOps tool: **Trivy** (Aqua Security), stage: **Security / DevSecOps**.

A small Flask app goes through a GitHub Actions pipeline:
`commit -> unit tests -> Trivy fs scan -> Docker build -> Trivy image scan (gate) -> SARIF + SBOM -> deploy`

## Repo layout
| Path | Purpose |
|---|---|
| `app/`, `tests/` | Demo Flask app and unit tests |
| `Dockerfile`, `requirements.txt` | **Secure/final** versions (pipeline passes) |
| `insecure/` | **"Before"** Dockerfile + requirements (pipeline fails) |
| `.github/workflows/devsecops.yml` | CI/CD pipeline with Trivy security gate |
| `local_scan.sh` | Same scans run locally |

## Install Trivy locally
- Ubuntu/Debian: follow https://trivy.dev (apt repo) or `sudo snap install trivy`
- macOS: `brew install trivy`
- Windows: `choco install trivy` or use the Docker image: `docker run --rm aquasec/trivy --help`

## Demo steps (take a screenshot at each step)
1. **Insecure run** - copy the insecure files over and push:
   ```bash
   cp insecure/Dockerfile Dockerfile
   cp insecure/requirements.txt requirements.txt
   git add . && git commit -m "demo: insecure baseline" && git push
   ```
   The *Trivy image scan* step fails the pipeline and the deploy job is skipped.
2. **Inspect findings** - Actions log (table), repo **Security -> Code scanning** tab (SARIF).
3. **Fix** - restore the secure files:
   ```bash
   git checkout main~1 -- Dockerfile requirements.txt   # or re-copy the secure versions
   git commit -am "fix: update base image and dependencies" && git push
   ```
4. **Passing run** - all stages green, deploy job runs, SBOM available under *Artifacts*.
5. **Local scan** - run `./local_scan.sh` and screenshot the terminal output.

## Notes
- Trivy's vulnerability database updates continuously, so exact CVE counts will differ from day to day. That's expected; report what *you* observe.
- `ignore-unfixed: true` hides CVEs that have no patch yet. Add justified exceptions to `.trivyignore`.
