#!/usr/bin/env bash
# Run the same checks locally (needs Docker + Trivy installed)
set -e
docker build -t demo-app:local .
echo "== Filesystem scan =="
trivy fs --scanners vuln,secret,misconfig --severity HIGH,CRITICAL .
echo "== Image scan =="
trivy image --severity HIGH,CRITICAL --ignore-unfixed demo-app:local
echo "== SBOM =="
trivy image --format cyclonedx --output sbom.cdx.json demo-app:local
